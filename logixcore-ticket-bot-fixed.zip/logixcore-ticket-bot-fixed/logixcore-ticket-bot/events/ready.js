// events/ready.js
const { Events } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ Bot online come ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: 'Gestione ticket LogixCore' }],
      status: 'online'
    });
  }
};
