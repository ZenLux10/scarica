// events/guildCreate.js
const { Events, EmbedBuilder } = require('discord.js');
const { isWhitelisted } = require('../utils/whitelist');

module.exports = {
  name: Events.GuildCreate,
  async execute(guild) {
    if (isWhitelisted(guild.id)) {
      console.log(`✅ Entrato nel server autorizzato: ${guild.name} (${guild.id})`);
      return;
    }

    console.log(`⛔ Server NON autorizzato: ${guild.name} (${guild.id}) — esco automaticamente.`);

    // Avvisa il proprietario del server (se possibile) prima di uscire
    try {
      const owner = await guild.fetchOwner();
      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('⛔ Server non autorizzato')
        .setDescription(
          `Questo bot è privato e funziona solo nei server autorizzati dall'owner.\n\n` +
          `ID del tuo server: \`${guild.id}\`\n\n` +
          `Se ritieni che il tuo server debba essere autorizzato, contatta l'owner del bot fornendo questo ID.`
        );
      await owner.send({ embeds: [embed] }).catch(() => {});
    } catch (err) {
      // ignora se non è possibile contattare il proprietario
    }

    await guild.leave().catch(err => console.error('Errore durante il leave:', err));
  }
};
