// events/interactionCreate.js
const { Events, MessageFlags } = require('discord.js');
const { TICKET_CATEGORIES } = require('../config/ticketConfig');
const { buildCategoryModal } = require('../utils/embeds');
const {
  createTicketChannel,
  claimTicket,
  unclaimTicket
} = require('../utils/ticketLifecycle');
const { memberHasStaffRole } = require('../utils/permissions');
const { isWhitelisted } = require('../utils/whitelist');

// Cooldown apertura ticket: userId -> timestamp
const cooldowns = new Map();
const COOLDOWN_MS = 120 * 1000;

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    try {
      // ---------- CONTROLLO WHITELIST SERVER ----------
      // Il comando /whitelist deve sempre funzionare per l'owner anche se il
      // server non è whitelistato, quindi viene escluso dal controllo.
      if (interaction.guild && interaction.commandName !== 'whitelist') {
        if (!isWhitelisted(interaction.guild.id)) {
          if (interaction.isRepliable()) {
            await interaction.reply({
              content: '⛔ Questo server non è autorizzato a usare questo bot.',
              flags: MessageFlags.Ephemeral
            }).catch(() => {});
          }
          await interaction.guild.leave().catch(() => {});
          return;
        }
      }

      // ---------- SLASH COMMANDS ----------
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return;
        await command.execute(interaction);
        return;
      }

      // ---------- SELECT MENU: scelta categoria ----------
      if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select_category') {
        const categoryId = interaction.values[0];
        const category = TICKET_CATEGORIES[categoryId];

        if (!category) {
          return interaction.reply({ content: 'Categoria non valida.', flags: MessageFlags.Ephemeral });
        }

        // Verifica se l'utente ha già un ticket aperto
        const existing = interaction.guild.channels.cache.find(
          ch => ch.topic === `TICKET|${interaction.user.id}|${category.id}`
        );
        if (existing) {
          return interaction.reply({
            content: `Hai già un ticket aperto: <#${existing.id}>`,
            flags: MessageFlags.Ephemeral
          });
        }

        // Cooldown
        const last = cooldowns.get(interaction.user.id);
        if (last && Date.now() - last < COOLDOWN_MS) {
          const remaining = Math.ceil((COOLDOWN_MS - (Date.now() - last)) / 1000);
          return interaction.reply({
            content: `Devi attendere ancora ${remaining}s prima di aprire un altro ticket.`,
            flags: MessageFlags.Ephemeral
          });
        }

        const modal = buildCategoryModal(category);
        await interaction.showModal(modal);
        return;
      }

      // ---------- MODAL SUBMIT: dati form ticket ----------
      if (interaction.isModalSubmit() && interaction.customId.startsWith('ticket_modal_')) {
        const categoryId = interaction.customId.replace('ticket_modal_', '');
        const category = TICKET_CATEGORIES[categoryId];
        if (!category) {
          return interaction.reply({ content: 'Categoria non valida.', flags: MessageFlags.Ephemeral });
        }

        // Limite 1 ticket totale per utente (qualsiasi categoria)
        const existingAny = interaction.guild.channels.cache.find(
          ch => ch.topic && ch.topic.startsWith(`TICKET|${interaction.user.id}|`)
        );
        if (existingAny) {
          return interaction.reply({
            content: `Hai già un ticket aperto: <#${existingAny.id}>`,
            flags: MessageFlags.Ephemeral
          });
        }

        const formData = {};
        for (const field of category.modal.fields) {
          const value = interaction.fields.getTextInputValue(field.id);
          formData[field.label] = value;
        }

        await createTicketChannel(interaction, categoryId, formData);

        cooldowns.set(interaction.user.id, Date.now());
        return;
      }

      // ---------- BUTTONS: claim / unclaim / close ----------
      if (interaction.isButton()) {
        switch (interaction.customId) {
          case 'ticket_claim': {
            if (!memberHasStaffRole(interaction.member)) {
              return interaction.reply({ content: 'Non hai i permessi per prendere in carico questo ticket.', flags: MessageFlags.Ephemeral });
            }
            return claimTicket(interaction);
          }

          case 'ticket_unclaim': {
            if (!memberHasStaffRole(interaction.member)) {
              return interaction.reply({ content: 'Non hai i permessi per rilasciare questo ticket.', flags: MessageFlags.Ephemeral });
            }
            return unclaimTicket(interaction);
          }

          case 'ticket_close': {
            if (!memberHasStaffRole(interaction.member)) {
              return interaction.reply({ content: 'Non hai i permessi per chiudere questo ticket.', flags: MessageFlags.Ephemeral });
            }
            await interaction.deferReply();
            const { closeTicket } = require('../utils/ticketLifecycle');
            await closeTicket(interaction, 'Chiuso tramite bottone');
            return;
          }
        }
      }
    } catch (error) {
      console.error('Errore interactionCreate:', error);
      if (interaction.isRepliable()) {
        const payload = { content: 'Si è verificato un errore durante l\'esecuzione.', flags: MessageFlags.Ephemeral };
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(payload).catch(() => {});
        } else {
          await interaction.reply(payload).catch(() => {});
        }
      }
    }
  }
};
