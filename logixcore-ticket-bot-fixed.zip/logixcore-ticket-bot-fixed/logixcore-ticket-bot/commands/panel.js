// commands/panel.js
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { buildPanelEmbed } = require('../utils/embeds');
const { getSettings } = require('../utils/guildSettings');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panel')
    .setDescription('Invia il pannello per l\'apertura dei ticket in questo canale.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const settings = getSettings(interaction.guild.id);
    const { embeds, components } = buildPanelEmbed(settings);
    await interaction.channel.send({ embeds, components });
    await interaction.reply({ content: 'Pannello ticket inviato.', ephemeral: true });
  }
};
