// commands/configura.js
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ChannelType
} = require('discord.js');
const { updateSettings, getSettings } = require('../utils/guildSettings');
const { TICKET_CATEGORIES } = require('../config/ticketConfig');

const categoryChoices = Object.values(TICKET_CATEGORIES).map(cat => ({
  name: cat.label,
  value: cat.id
}));

module.exports = {
  data: new SlashCommandBuilder()
    .setName('configura')
    .setDescription('Configura il bot per questo server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)

    // /configura log-channel canale:#log
    .addSubcommand(sub =>
      sub.setName('log-channel')
        .setDescription('Imposta il canale dove vengono inviati log e transcript')
        .addChannelOption(opt =>
          opt.setName('canale')
            .setDescription('Canale di testo per i log')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)))

    // /configura ticket-category categoria:Ticket
    .addSubcommand(sub =>
      sub.setName('ticket-category')
        .setDescription('Imposta la categoria Discord dove vengono creati i canali ticket')
        .addChannelOption(opt =>
          opt.setName('categoria')
            .setDescription('Categoria Discord')
            .addChannelTypes(ChannelType.GuildCategory)
            .setRequired(true)))

    // /configura staff-role azione:aggiungi ruolo:@Staff
    .addSubcommand(sub =>
      sub.setName('staff-role')
        .setDescription('Aggiungi o rimuovi un ruolo staff generale (gestisce tutti i ticket)')
        .addStringOption(opt =>
          opt.setName('azione')
            .setDescription('Aggiungi o rimuovi il ruolo')
            .setRequired(true)
            .addChoices(
              { name: 'Aggiungi', value: 'add' },
              { name: 'Rimuovi', value: 'remove' }
            ))
        .addRoleOption(opt =>
          opt.setName('ruolo')
            .setDescription('Ruolo staff')
            .setRequired(true)))

    // /configura category-role categoria:Supporto azione:aggiungi ruolo:@SupportTeam
    .addSubcommand(sub =>
      sub.setName('category-role')
        .setDescription('Aggiungi o rimuovi un ruolo per una categoria di ticket specifica')
        .addStringOption(opt =>
          opt.setName('categoria')
            .setDescription('Categoria ticket')
            .setRequired(true)
            .addChoices(...categoryChoices))
        .addStringOption(opt =>
          opt.setName('azione')
            .setDescription('Aggiungi o rimuovi il ruolo')
            .setRequired(true)
            .addChoices(
              { name: 'Aggiungi', value: 'add' },
              { name: 'Rimuovi', value: 'remove' }
            ))
        .addRoleOption(opt =>
          opt.setName('ruolo')
            .setDescription('Ruolo da assegnare alla categoria')
            .setRequired(true)))

    // /configura branding nome:"Il Mio Server" icona:<url>
    .addSubcommand(sub =>
      sub.setName('branding')
        .setDescription('Personalizza nome e icona mostrati negli embed dei ticket')
        .addStringOption(opt =>
          opt.setName('nome')
            .setDescription('Nome del server da mostrare negli embed')
            .setRequired(false))
        .addStringOption(opt =>
          opt.setName('icona')
            .setDescription('URL icona/logo da mostrare negli embed')
            .setRequired(false)))

    // /configura view
    .addSubcommand(sub =>
      sub.setName('view')
        .setDescription('Visualizza la configurazione attuale del bot per questo server')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    switch (sub) {
      case 'log-channel': {
        const channel = interaction.options.getChannel('canale');
        updateSettings(guildId, s => ({ ...s, logChannelId: channel.id }));
        return interaction.reply({ content: `✅ Canale log impostato su <#${channel.id}>.`, ephemeral: true });
      }

      case 'ticket-category': {
        const category = interaction.options.getChannel('categoria');
        updateSettings(guildId, s => ({ ...s, ticketCategoryId: category.id }));
        return interaction.reply({ content: `✅ Categoria ticket impostata su **${category.name}**.`, ephemeral: true });
      }

      case 'staff-role': {
        const azione = interaction.options.getString('azione');
        const role = interaction.options.getRole('ruolo');

        const updated = updateSettings(guildId, s => {
          const roles = new Set(s.supportRoleIds || []);
          if (azione === 'add') roles.add(role.id);
          else roles.delete(role.id);
          return { ...s, supportRoleIds: [...roles] };
        });

        const action = azione === 'add' ? 'aggiunto a' : 'rimosso da';
        return interaction.reply({
          content: `✅ Ruolo <@&${role.id}> ${action} i ruoli staff generali.\nRuoli attuali: ${updated.supportRoleIds.map(id => `<@&${id}>`).join(', ') || 'nessuno'}`,
          ephemeral: true
        });
      }

      case 'category-role': {
        const categoryId = interaction.options.getString('categoria');
        const azione = interaction.options.getString('azione');
        const role = interaction.options.getRole('ruolo');
        const category = TICKET_CATEGORIES[categoryId];

        const updated = updateSettings(guildId, s => {
          const roles = new Set(s.categoryRoleIds[categoryId] || []);
          if (azione === 'add') roles.add(role.id);
          else roles.delete(role.id);
          return {
            ...s,
            categoryRoleIds: { ...s.categoryRoleIds, [categoryId]: [...roles] }
          };
        });

        const action = azione === 'add' ? 'aggiunto a' : 'rimosso da';
        const current = updated.categoryRoleIds[categoryId];
        return interaction.reply({
          content: `✅ Ruolo <@&${role.id}> ${action} la categoria **${category.label}**.\nRuoli attuali: ${current.map(id => `<@&${id}>`).join(', ') || 'nessuno (verranno usati i ruoli staff generali)'}`,
          ephemeral: true
        });
      }

      case 'branding': {
        const nome = interaction.options.getString('nome');
        const icona = interaction.options.getString('icona');

        if (!nome && !icona) {
          return interaction.reply({ content: 'Specifica almeno `nome` o `icona`.', ephemeral: true });
        }

        if (icona && !/^https?:\/\/.+/i.test(icona)) {
          return interaction.reply({ content: 'L\'icona deve essere un URL valido (http/https).', ephemeral: true });
        }

        updateSettings(guildId, s => ({
          ...s,
          guildName: nome ?? s.guildName,
          iconUrl: icona ?? s.iconUrl
        }));

        return interaction.reply({ content: '✅ Branding aggiornato.', ephemeral: true });
      }

      case 'view': {
        const settings = getSettings(guildId);

        const categoryRolesText = Object.entries(settings.categoryRoleIds)
          .map(([catId, roles]) => {
            const label = TICKET_CATEGORIES[catId]?.label || catId;
            const value = roles.length ? roles.map(id => `<@&${id}>`).join(', ') : '_(usa ruoli staff generali)_';
            return `**${label}**: ${value}`;
          })
          .join('\n');

        const embed = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle('⚙️ Configurazione LogixCore Ticket Bot')
          .addFields(
            { name: 'Canale log', value: settings.logChannelId ? `<#${settings.logChannelId}>` : '_non impostato_', inline: false },
            { name: 'Categoria ticket', value: settings.ticketCategoryId ? `<#${settings.ticketCategoryId}>` : '_non impostata_', inline: false },
            { name: 'Ruoli staff generali', value: settings.supportRoleIds.length ? settings.supportRoleIds.map(id => `<@&${id}>`).join(', ') : '_nessuno_', inline: false },
            { name: 'Ruoli per categoria', value: categoryRolesText || '_nessuno_', inline: false },
            { name: 'Nome branding', value: settings.guildName || `_${interaction.guild.name}_ (default)`, inline: false },
            { name: 'Icona branding', value: settings.iconUrl || '_default_', inline: false }
          );

        return interaction.reply({ embeds: [embed], ephemeral: true });
      }
    }
  }
};
