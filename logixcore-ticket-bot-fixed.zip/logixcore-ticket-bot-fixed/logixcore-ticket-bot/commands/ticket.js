// commands/ticket.js
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder
} = require('discord.js');
const { memberHasStaffRole } = require('../utils/permissions');
const { closeTicket } = require('../utils/ticketLifecycle');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Comandi di gestione ticket')
    .addSubcommand(sub =>
      sub.setName('rename')
        .setDescription('Rinomina il canale ticket')
        .addStringOption(opt =>
          opt.setName('nome')
            .setDescription('Nuovo nome del canale')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('add-user')
        .setDescription('Aggiungi un utente al ticket')
        .addUserOption(opt =>
          opt.setName('utente')
            .setDescription('Utente da aggiungere')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove-user')
        .setDescription('Rimuovi un utente dal ticket')
        .addUserOption(opt =>
          opt.setName('utente')
            .setDescription('Utente da rimuovere')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('transcript')
        .setDescription('Genera la transcript del ticket senza chiuderlo'))
    .addSubcommand(sub =>
      sub.setName('notes')
        .setDescription('Aggiungi una nota interna al ticket (visibile solo allo staff)')
        .addStringOption(opt =>
          opt.setName('testo')
            .setDescription('Contenuto della nota')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('close')
        .setDescription('Chiudi il ticket e genera la transcript')
        .addStringOption(opt =>
          opt.setName('motivo')
            .setDescription('Motivo della chiusura')
            .setRequired(false))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const channel = interaction.channel;

    // Verifica che il comando sia usato in un canale ticket
    const ticketData = channel.topic ? parseTopic(channel.topic) : null;
    if (!ticketData) {
      return interaction.reply({ content: 'Questo comando può essere usato solo in un canale ticket.', ephemeral: true });
    }

    const isStaff = memberHasStaffRole(interaction.member);
    const isOwner = ticketData.userId === interaction.user.id;

    if (!isStaff && !isOwner) {
      return interaction.reply({ content: 'Non hai i permessi per usare questo comando qui.', ephemeral: true });
    }

    switch (sub) {
      case 'rename': {
        if (!isStaff) return interaction.reply({ content: 'Solo lo staff può rinominare il ticket.', ephemeral: true });
        const nome = interaction.options.getString('nome');
        await channel.setName(nome);
        return interaction.reply({ content: `Canale rinominato in **${nome}**.`, ephemeral: true });
      }

      case 'add-user': {
        if (!isStaff) return interaction.reply({ content: 'Solo lo staff può aggiungere utenti.', ephemeral: true });
        const user = interaction.options.getUser('utente');
        await channel.permissionOverwrites.create(user.id, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true
        });
        return interaction.reply({ content: `<@${user.id}> è stato aggiunto al ticket.` });
      }

      case 'remove-user': {
        if (!isStaff) return interaction.reply({ content: 'Solo lo staff può rimuovere utenti.', ephemeral: true });
        const user = interaction.options.getUser('utente');
        await channel.permissionOverwrites.delete(user.id);
        return interaction.reply({ content: `<@${user.id}> è stato rimosso dal ticket.` });
      }

      case 'transcript': {
        if (!isStaff) return interaction.reply({ content: 'Solo lo staff può generare la transcript.', ephemeral: true });
        await interaction.deferReply({ ephemeral: true });
        const { generateAndSendTranscript } = require('../utils/ticketLifecycle');
        await generateAndSendTranscript(interaction, { closing: false });
        return interaction.editReply({ content: 'Transcript generata e inviata.' });
      }

      case 'notes': {
        if (!isStaff) return interaction.reply({ content: 'Solo lo staff può aggiungere note.', ephemeral: true });
        const testo = interaction.options.getString('testo');
        const embed = new EmbedBuilder()
          .setColor(0xf1c40f)
          .setTitle('📝 Nota interna')
          .setDescription(testo)
          .setFooter({ text: `Aggiunta da ${interaction.user.tag}` })
          .setTimestamp();
        await interaction.reply({ embeds: [embed] });
        return;
      }

      case 'close': {
        if (!isStaff) return interaction.reply({ content: 'Solo lo staff può chiudere il ticket.', ephemeral: true });
        const motivo = interaction.options.getString('motivo') || 'Nessun motivo specificato';
        await interaction.deferReply();
        await closeTicket(interaction, motivo);
        return;
      }
    }
  }
};

function parseTopic(topic) {
  // topic format: "TICKET|userId|categoryId"
  if (!topic || !topic.startsWith('TICKET|')) return null;
  const [, userId, categoryId] = topic.split('|');
  if (!userId || !categoryId) return null;
  return { userId, categoryId };
}
