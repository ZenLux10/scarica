// commands/whitelist.js
const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { getWhitelist, addGuild, removeGuild, isWhitelisted } = require('../utils/whitelist');

function isBotOwner(userId) {
  const ownerIds = (process.env.BOT_OWNER_ID || '')
    .split(',')
    .map(id => id.trim())
    .filter(Boolean);
  return ownerIds.includes(userId);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('[Owner] Gestisci i server autorizzati a usare il bot')
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Autorizza un server (whitelist)')
        .addStringOption(opt =>
          opt.setName('guild_id')
            .setDescription('ID del server da autorizzare')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Rimuovi un server dalla whitelist')
        .addStringOption(opt =>
          opt.setName('guild_id')
            .setDescription('ID del server da rimuovere')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('Mostra la lista dei server autorizzati'))
    .addSubcommand(sub =>
      sub.setName('check')
        .setDescription('Controlla se un server è in whitelist')
        .addStringOption(opt =>
          opt.setName('guild_id')
            .setDescription('ID del server da controllare')
            .setRequired(true))),

  async execute(interaction) {
    if (!isBotOwner(interaction.user.id)) {
      return interaction.reply({
        content: '⛔ Solo l\'owner del bot può usare questo comando.',
        flags: MessageFlags.Ephemeral
      });
    }

    const sub = interaction.options.getSubcommand();

    switch (sub) {
      case 'add': {
        const guildId = interaction.options.getString('guild_id');
        const added = addGuild(guildId);

        if (!added) {
          return interaction.reply({ content: `⚠️ Il server \`${guildId}\` è già in whitelist.`, flags: MessageFlags.Ephemeral });
        }

        return interaction.reply({ content: `✅ Server \`${guildId}\` aggiunto alla whitelist.`, flags: MessageFlags.Ephemeral });
      }

      case 'remove': {
        const guildId = interaction.options.getString('guild_id');
        const removed = removeGuild(guildId);

        if (!removed) {
          return interaction.reply({ content: `⚠️ Il server \`${guildId}\` non era in whitelist.`, flags: MessageFlags.Ephemeral });
        }

        // Se il bot è ancora presente in quel server, esce automaticamente
        const guild = interaction.client.guilds.cache.get(guildId);
        if (guild) {
          await guild.leave().catch(() => {});
        }

        return interaction.reply({ content: `✅ Server \`${guildId}\` rimosso dalla whitelist${guild ? ' e il bot ha lasciato il server' : ''}.`, flags: MessageFlags.Ephemeral });
      }

      case 'list': {
        const list = getWhitelist();

        if (list.length === 0) {
          return interaction.reply({ content: 'La whitelist è vuota.', flags: MessageFlags.Ephemeral });
        }

        const lines = list.map(id => {
          const guild = interaction.client.guilds.cache.get(id);
          return `\`${id}\` ${guild ? `— ${guild.name} (${guild.memberCount} membri)` : '— _bot non presente_'}`;
        });

        const embed = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle('📋 Server in whitelist')
          .setDescription(lines.join('\n'));

        return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
      }

      case 'check': {
        const guildId = interaction.options.getString('guild_id');
        const ok = isWhitelisted(guildId);
        return interaction.reply({
          content: ok ? `✅ Il server \`${guildId}\` è autorizzato.` : `❌ Il server \`${guildId}\` NON è autorizzato.`,
          flags: MessageFlags.Ephemeral
        });
      }
    }
  }
};
