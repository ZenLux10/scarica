// config/ticketConfig.js
// Configurazione centrale di tutte le categorie ticket, modal e testi.

require('dotenv').config();

const TICKET_CATEGORIES = {
  supporto: {
    id: 'supporto',
    label: 'Supporto',
    emoji: '🛠️',
    description: 'Assistenza tecnica, bug, problemi con servizi o configurazioni.',
    channelPrefix: 'support',
    embedTitle: 'Supporto',
    embedDescription: 'Scrivi qui i dettagli della richiesta.',
    icon: 'https://i.imgur.com/4M34hi2.png', // nuvola
    roleEnv: 'ROLE_SUPPORTO',
    modal: {
      title: 'Supporto',
      fields: [
        { id: 'oggetto', label: 'Oggetto della richiesta', style: 'SHORT', placeholder: 'Es. Problema con il pannello ticket', required: true },
        { id: 'dettagli', label: 'Dettagli tecnici', style: 'PARAGRAPH', placeholder: 'Spiega con precisione cosa succede, quando succede e come riprodurlo.', required: true },
        { id: 'priorita', label: 'Priorita richiesta', style: 'SHORT', placeholder: 'Bassa, media o alta', required: true }
      ]
    }
  },
  acquisti: {
    id: 'acquisti',
    label: 'Acquisti',
    emoji: '💳',
    description: 'Richieste pre-vendita, prezzi, rinnovi, upgrade e bundle.',
    channelPrefix: 'acquisti',
    embedTitle: 'Acquisti',
    embedDescription: 'Scrivi qui i dettagli della richiesta.',
    icon: 'https://i.imgur.com/4M34hi2.png',
    roleEnv: 'ROLE_ACQUISTI',
    modal: {
      title: 'Acquisti',
      fields: [
        { id: 'prodotto', label: 'Prodotto o servizio', style: 'SHORT', placeholder: 'Es. Piano Enterprise', required: true },
        { id: 'budget', label: 'Budget indicativo', style: 'SHORT', placeholder: 'Es. 50-100 EUR / mese', required: false },
        { id: 'dettagli', label: 'Dettagli della richiesta', style: 'PARAGRAPH', placeholder: 'Spiega cosa vuoi acquistare o aggiornare.', required: true }
      ]
    }
  },
  partnership: {
    id: 'partnership',
    label: 'Partnership',
    emoji: '🤝',
    description: 'Collaborazioni, sponsorizzazioni, ambassador e joint activity.',
    channelPrefix: 'partnership',
    embedTitle: 'Partnership',
    embedDescription: 'Scrivi qui i dettagli della richiesta.',
    icon: 'https://i.imgur.com/4M34hi2.png',
    roleEnv: 'ROLE_PARTNERSHIP',
    modal: {
      title: 'Partnership',
      fields: [
        { id: 'progetto', label: 'Nome progetto o brand', style: 'SHORT', placeholder: 'Es. LogixCore Media', required: true },
        { id: 'proposta', label: 'Proposta partnership', style: 'PARAGRAPH', placeholder: 'Descrivi la collaborazione, il pubblico e gli obiettivi.', required: true },
        { id: 'canali', label: 'Canali e numeri', style: 'PARAGRAPH', placeholder: 'Inserisci audience, link e metriche rilevanti.', required: false }
      ]
    }
  },
  segnalazioni: {
    id: 'segnalazioni',
    label: 'Segnalazioni',
    emoji: '🚩',
    description: 'Abusi, comportamenti scorretti, vulnerabilità o incidenti.',
    channelPrefix: 'segnalazioni',
    embedTitle: 'Segnalazioni',
    embedDescription: 'Scrivi qui i dettagli della richiesta.',
    icon: 'https://i.imgur.com/4M34hi2.png',
    roleEnv: 'ROLE_SEGNALAZIONI',
    modal: {
      title: 'Segnalazioni',
      fields: [
        { id: 'utente_area', label: 'Utente o area coinvolta', style: 'SHORT', placeholder: 'Es. @Utente, canale, funzione', required: true },
        { id: 'descrizione', label: 'Descrizione della segnalazione', style: 'PARAGRAPH', placeholder: "Spiega cosa è successo e quando.", required: true },
        { id: 'prove', label: 'Prove disponibili', style: 'PARAGRAPH', placeholder: 'Link, screenshot, ID messaggi o qualsiasi prova utile.', required: false }
      ]
    }
  },
  candidature: {
    id: 'candidature',
    label: 'Candidature',
    emoji: '📋',
    description: 'Application staff, creator program o ruoli interni.',
    channelPrefix: 'candidatura',
    embedTitle: 'Candidature',
    embedDescription: 'Scrivi qui i dettagli della richiesta.',
    icon: 'https://i.imgur.com/4M34hi2.png',
    roleEnv: 'ROLE_CANDIDATURE',
    modal: {
      title: 'Candidature',
      fields: [
        { id: 'ruolo', label: 'Ruolo desiderato', style: 'SHORT', placeholder: 'Es. Moderator', required: true },
        { id: 'esperienza', label: 'Esperienza rilevante', style: 'PARAGRAPH', placeholder: 'Riassumi esperienza, disponibilita e punti di forza.', required: true },
        { id: 'motivazione', label: 'Perche dovremmo sceglierti', style: 'PARAGRAPH', placeholder: 'Spiega il valore che porteresti al team.', required: true }
      ]
    }
  },
  altro: {
    id: 'altro',
    label: 'Altro',
    emoji: '❓',
    description: 'Richieste generiche che non rientrano nelle altre code.',
    channelPrefix: 'altro',
    embedTitle: 'Altro',
    embedDescription: 'Scrivi qui i dettagli della richiesta.',
    icon: 'https://i.imgur.com/4M34hi2.png',
    roleEnv: 'ROLE_ALTRO',
    modal: {
      title: 'Altro',
      fields: [
        { id: 'motivo', label: 'Motivo del ticket', style: 'SHORT', placeholder: 'Es. Richiesta generale', required: true },
        { id: 'dettagli', label: 'Dettagli', style: 'PARAGRAPH', placeholder: 'Descrivi con precisione di cosa hai bisogno.', required: true }
      ]
    }
  }
};

module.exports = { TICKET_CATEGORIES };
