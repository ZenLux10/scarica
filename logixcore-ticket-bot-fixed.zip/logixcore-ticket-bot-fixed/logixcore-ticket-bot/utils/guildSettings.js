// utils/guildSettings.js
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data', 'guilds');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DEFAULT_SETTINGS = {
  logChannelId: null,
  ticketCategoryId: null,
  supportRoleIds: [],          // ruoli staff generali
  categoryRoleIds: {            // ruoli specifici per categoria ticket
    supporto: [],
    acquisti: [],
    partnership: [],
    segnalazioni: [],
    candidature: [],
    altro: []
  },
  guildName: null,              // se null, usa guild.name
  iconUrl: null                 // se null, usa icona di default
};

const cache = new Map();

function getFilePath(guildId) {
  return path.join(DATA_DIR, `${guildId}.json`);
}

function getSettings(guildId) {
  if (cache.has(guildId)) return cache.get(guildId);

  const filePath = getFilePath(guildId);
  let settings = { ...DEFAULT_SETTINGS, categoryRoleIds: { ...DEFAULT_SETTINGS.categoryRoleIds } };

  if (fs.existsSync(filePath)) {
    try {
      const raw = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      settings = {
        ...settings,
        ...raw,
        categoryRoleIds: { ...settings.categoryRoleIds, ...(raw.categoryRoleIds || {}) }
      };
    } catch (err) {
      console.error(`Errore lettura settings per guild ${guildId}:`, err);
    }
  }

  cache.set(guildId, settings);
  return settings;
}

function saveSettings(guildId, settings) {
  cache.set(guildId, settings);
  fs.writeFileSync(getFilePath(guildId), JSON.stringify(settings, null, 2), 'utf-8');
}

function updateSettings(guildId, updater) {
  const current = getSettings(guildId);
  const updated = updater({ ...current, categoryRoleIds: { ...current.categoryRoleIds } });
  saveSettings(guildId, updated);
  return updated;
}

module.exports = { getSettings, saveSettings, updateSettings, DEFAULT_SETTINGS };
