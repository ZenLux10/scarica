// utils/whitelist.js
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const FILE_PATH = path.join(DATA_DIR, 'whitelist.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function load() {
  if (!fs.existsSync(FILE_PATH)) {
    save([]);
    return [];
  }
  try {
    const raw = JSON.parse(fs.readFileSync(FILE_PATH, 'utf-8'));
    return Array.isArray(raw) ? raw : [];
  } catch (err) {
    console.error('Errore lettura whitelist:', err);
    return [];
  }
}

function save(list) {
  fs.writeFileSync(FILE_PATH, JSON.stringify(list, null, 2), 'utf-8');
}

function getWhitelist() {
  return load();
}

function isWhitelisted(guildId) {
  const list = load();
  return list.includes(guildId);
}

function addGuild(guildId) {
  const list = load();
  if (!list.includes(guildId)) {
    list.push(guildId);
    save(list);
    return true;
  }
  return false;
}

function removeGuild(guildId) {
  const list = load();
  const index = list.indexOf(guildId);
  if (index !== -1) {
    list.splice(index, 1);
    save(list);
    return true;
  }
  return false;
}

module.exports = { getWhitelist, isWhitelisted, addGuild, removeGuild };
