// utils/ticketLifecycle.js
const {
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder,
  AttachmentBuilder
} = require('discord.js');

const { TICKET_CATEGORIES } = require('../config/ticketConfig');
const { getCategoryRoleIds } = require('./permissions');
const { getSettings } = require('./guildSettings');
const {
  buildTicketCreatedEmbed,
  buildTicketChannelEmbed,
  buildTicketControlRow,
  buildTranscriptEmbed
} = require('./embeds');

// Mappa in memoria: channelId -> { claimedBy: userId|null }
const ticketState = new Map();

// ---------------- CREAZIONE TICKET ----------------
async function createTicketChannel(interaction, categoryId, formData) {
  const category = TICKET_CATEGORIES[categoryId];
  const guild = interaction.guild;
  const user = interaction.user;
  const settings = getSettings(guild.id);

  const username = user.username.toLowerCase().replace(/[^a-z0-9]/g, '');
  const channelName = `${category.channelPrefix}-${username}`;

  const roleIds = getCategoryRoleIds(guild.id, category);

  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel]
    },
    {
      id: user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks
      ]
    }
  ];

  for (const roleId of roleIds) {
    overwrites.push({
      id: roleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks
      ]
    });
  }

  const channelOptions = {
    name: channelName,
    type: ChannelType.GuildText,
    topic: `TICKET|${user.id}|${category.id}`,
    permissionOverwrites: overwrites
  };

  if (settings.ticketCategoryId) {
    channelOptions.parent = settings.ticketCategoryId;
  }

  // Defer subito per evitare DiscordAPIError[10062] (token scade dopo 3s)
  await interaction.deferReply({ ephemeral: true });

  const channel = await guild.channels.create(channelOptions);

  // Inizializza stato ticket
  ticketState.set(channel.id, { claimedBy: null });

  // Embed principale nel canale (immagine 4)
  const embed = buildTicketChannelEmbed(category, user, formData, settings);
  const row = buildTicketControlRow(null);

  const pingRoles = roleIds.map(id => `<@&${id}>`).join(' ');

  await channel.send({
    content: `<@${user.id}>${pingRoles ? ' ' + pingRoles : ''}`,
    embeds: [embed],
    components: [row]
  });

  // Risposta effimera al player (già deferrata sopra)
  const createdEmbed = buildTicketCreatedEmbed(channel, category, settings);
  await interaction.editReply({ ...createdEmbed });

  // Log nel canale log (apertura)
  await logTicketEvent(guild, {
    title: 'Ticket aperto',
    description: `Categoria: **${category.label}**\nUtente: <@${user.id}>\nCanale: <#${channel.id}>`,
    color: 0x2ecc71
  });

  return channel;
}

// ---------------- CLAIM / UNCLAIM ----------------
async function claimTicket(interaction) {
  const channel = interaction.channel;
  const state = ticketState.get(channel.id) || { claimedBy: null };

  if (state.claimedBy) {
    return interaction.reply({ content: 'Questo ticket è già stato preso in carico.', ephemeral: true });
  }

  // Defer subito per evitare DiscordAPIError[10062] (token scade dopo 3s)
  await interaction.deferReply();

  state.claimedBy = interaction.user.id;
  ticketState.set(channel.id, state);

  await updateTicketEmbed(channel, { claimedBy: state.claimedBy });

  return interaction.editReply({ content: `🎫 Ticket preso in carico da <@${interaction.user.id}>.` });
}

async function unclaimTicket(interaction) {
  const channel = interaction.channel;
  const state = ticketState.get(channel.id) || { claimedBy: null };

  if (!state.claimedBy) {
    return interaction.reply({ content: 'Questo ticket non è ancora stato preso in carico.', ephemeral: true });
  }

  // Defer subito per evitare DiscordAPIError[10062] (token scade dopo 3s)
  await interaction.deferReply();

  state.claimedBy = null;
  ticketState.set(channel.id, state);

  await updateTicketEmbed(channel, { claimedBy: null });

  return interaction.editReply({ content: `🪐 Ticket rilasciato da <@${interaction.user.id}>.` });
}

async function updateTicketEmbed(channel, { claimedBy }) {
  const messages = await channel.messages.fetch({ limit: 10 });
  const ticketMsg = messages.find(m => m.author.id === channel.client.user.id && m.embeds.length > 0 && m.components.length > 0);
  if (!ticketMsg) return;

  const oldEmbed = ticketMsg.embeds[0];
  const newEmbed = new EmbedBuilder(oldEmbed.data);

  const fields = newEmbed.data.fields || [];
  const claimFieldIndex = fields.findIndex(f => f.name === 'Claim');
  const claimValue = claimedBy ? `<@${claimedBy}>` : 'Non assegnato';

  if (claimFieldIndex !== -1) {
    fields[claimFieldIndex].value = claimValue;
  } else {
    fields.push({ name: 'Claim', value: claimValue, inline: false });
  }

  newEmbed.setFields(fields);

  const row = buildTicketControlRow(claimedBy);

  await ticketMsg.edit({ embeds: [newEmbed], components: [row] });
}

// ---------------- CHIUSURA TICKET ----------------
async function closeTicket(interaction, motivo) {
  await generateAndSendTranscript(interaction, { closing: true, motivo });

  const channel = interaction.channel;
  ticketState.delete(channel.id);

  setTimeout(async () => {
    try {
      await channel.delete();
    } catch (err) {
      console.error('Errore durante la chiusura del canale:', err);
    }
  }, 3000);
}

// ---------------- GENERAZIONE TRANSCRIPT (TXT) ----------------
async function buildTxtTranscript(channel) {
  let messages = [];
  let lastId;
  while (true) {
    const opts = { limit: 100 };
    if (lastId) opts.before = lastId;
    const batch = await channel.messages.fetch(opts);
    if (batch.size === 0) break;
    messages = messages.concat([...batch.values()]);
    lastId = batch.last().id;
    if (batch.size < 100) break;
  }

  messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);

  const lines = [
    `=== TRANSCRIPT: #${channel.name} ===`,
    `Data: ${new Date().toLocaleString('it-IT')}`,
    `Messaggi totali: ${messages.length}`,
    '='.repeat(50),
    ''
  ];

  for (const msg of messages) {
    const time = msg.createdAt.toLocaleString('it-IT');
    const author = msg.author.bot ? `[BOT] ${msg.author.tag}` : msg.author.tag;
    let line = `[${time}] ${author}: `;
    if (msg.content) line += msg.content;
    if (msg.embeds.length > 0) line += ` [Embed: ${msg.embeds[0].title || '(senza titolo)'}]`;
    if (msg.attachments.size > 0) {
      const urls = [...msg.attachments.values()].map(a => a.url).join(', ');
      line += ` [Allegati: ${urls}]`;
    }
    lines.push(line);
  }

  const buffer = Buffer.from(lines.join('\n'), 'utf-8');
  return new AttachmentBuilder(buffer, { name: `transcript-${channel.name}-${Date.now()}.txt` });
}

async function generateAndSendTranscript(interaction, { closing, motivo }) {
  const channel = interaction.channel;
  const guild = interaction.guild;
  const settings = getSettings(guild.id);

  const topic = channel.topic || '';
  const [, userId, categoryId] = topic.split('|');
  const category = TICKET_CATEGORIES[categoryId] || TICKET_CATEGORIES.altro;

  const state = ticketState.get(channel.id) || { claimedBy: null };

  const attachment = await buildTxtTranscript(channel);

  const transcriptEmbed = buildTranscriptEmbed({
    category,
    motivo: closing ? motivo : 'Transcript richiesta dallo staff',
    staffTag: state.claimedBy || interaction.user.id,
    guildName: settings.guildName || guild.name,
    settings
  });

  try {
    const targetUser = await guild.client.users.fetch(userId);
    await targetUser.send({ embeds: [transcriptEmbed], files: [attachment] });
  } catch (err) {
    console.error("Impossibile inviare la transcript in DM all'utente:", err.message);
  }

  await sendTranscriptToLogChannel(guild, transcriptEmbed, attachment);

  if (closing) {
    await interaction.editReply({
      content: `Ticket chiuso da <@${interaction.user.id}>. Motivo: ${motivo}\nQuesto canale verrà eliminato a breve.`
    }).catch(() => {});

    await logTicketEvent(guild, {
      title: 'Ticket chiuso',
      description: `Categoria: **${category.label}**\nUtente: <@${userId}>\nChiuso da: <@${interaction.user.id}>\nMotivo: ${motivo}`,
      color: 0xe74c3c
    });
  }
}

// ---------------- LOG GENERICI ----------------
async function logTicketEvent(guild, { title, description, color }) {
  const settings = getSettings(guild.id);
  const logChannelId = settings.logChannelId;
  if (!logChannelId) return;

  const logChannel = await guild.channels.fetch(logChannelId).catch(() => null);
  if (!logChannel) return;

  const embed = new EmbedBuilder()
    .setColor(color || 0x5865F2)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();

  await logChannel.send({ embeds: [embed] }).catch(() => {});
}

async function sendTranscriptToLogChannel(guild, transcriptEmbed, attachment) {
  const settings = getSettings(guild.id);
  const logChannelId = settings.logChannelId;
  if (!logChannelId) return;

  const logChannel = await guild.channels.fetch(logChannelId).catch(() => null);
  if (!logChannel) return;

  await logChannel.send({ embeds: [transcriptEmbed], files: [attachment] }).catch(() => {});
}

module.exports = {
  createTicketChannel,
  claimTicket,
  unclaimTicket,
  closeTicket,
  generateAndSendTranscript,
  ticketState
};
