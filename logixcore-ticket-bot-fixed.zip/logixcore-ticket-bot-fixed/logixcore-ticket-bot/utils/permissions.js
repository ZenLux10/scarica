// utils/permissions.js
const { getSettings } = require('./guildSettings');

function getSupportRoleIds(guildId) {
  const settings = getSettings(guildId);
  return settings.supportRoleIds || [];
}

function getCategoryRoleIds(guildId, category) {
  const settings = getSettings(guildId);
  const ids = (settings.categoryRoleIds && settings.categoryRoleIds[category.id]) || [];
  if (ids.length > 0) return ids;
  return getSupportRoleIds(guildId);
}

function memberHasStaffRole(member, category = null) {
  if (member.permissions.has('Administrator')) return true;

  const roleIds = category
    ? getCategoryRoleIds(member.guild.id, category)
    : getSupportRoleIds(member.guild.id);

  return roleIds.some(id => member.roles.cache.has(id));
}

module.exports = { getSupportRoleIds, getCategoryRoleIds, memberHasStaffRole };
