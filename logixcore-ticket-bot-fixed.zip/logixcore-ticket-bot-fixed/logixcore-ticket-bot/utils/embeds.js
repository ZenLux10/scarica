// utils/embeds.js
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { TICKET_CATEGORIES } = require('../config/ticketConfig');

const LOGIXCORE_COLOR = 0x5865F2;
const DEFAULT_ICON = 'https://i.imgur.com/4M34hi2.png';

function resolveIcon(settings) {
  return (settings && settings.iconUrl) || DEFAULT_ICON;
}

// ---------- PANNELLO "Apri un ticket" (immagine 2) ----------
function buildPanelEmbed(settings = {}) {
  const icon = resolveIcon(settings);

  const embed = new EmbedBuilder()
    .setColor(LOGIXCORE_COLOR)
    .setAuthor({ name: 'LogixCore', iconURL: icon })
    .setTitle('Apri un ticket')
    .setThumbnail(icon)
    .addFields(
      Object.values(TICKET_CATEGORIES).map(cat => ({
        name: cat.label,
        value: cat.description,
        inline: false
      }))
    )
    .setFooter({ text: 'Limite 1 ticket | Cooldown 120s' });

  // Per replicare visivamente la sezione "Categorie" come titolo separato
  embed.spliceFields(0, 0, { name: 'Categorie', value: '\u200b' });

  const select = new StringSelectMenuBuilder()
    .setCustomId('ticket_select_category')
    .setPlaceholder('Seleziona una categoria')
    .addOptions(
      Object.values(TICKET_CATEGORIES).map(cat => ({
        label: cat.label,
        description: cat.description.slice(0, 100),
        value: cat.id,
        emoji: cat.emoji
      }))
    );

  const row = new ActionRowBuilder().addComponents(select);

  return { embeds: [embed], components: [row] };
}

// ---------- Messaggio "Ticket creato" visibile solo al player (immagine 3) ----------
function buildTicketCreatedEmbed(channel, category, settings = {}) {
  const icon = resolveIcon(settings);

  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle('Ticket creato')
    .setDescription(`Il tuo ticket e pronto in <#${channel.id}>.`)
    .setThumbnail(icon)
    .addFields(
      { name: 'Categoria', value: category.label, inline: false },
      { name: 'Stato', value: 'Aperto', inline: false }
    );

  return { embeds: [embed] };
}

// ---------- Embed principale dentro il canale ticket (immagine 4) ----------
function buildTicketChannelEmbed(category, user, formData = null, settings = {}) {
  const icon = resolveIcon(settings);

  const embed = new EmbedBuilder()
    .setColor(0x2f3136)
    .setTitle(category.embedTitle)
    .setDescription(category.embedDescription)
    .setThumbnail(category.icon || icon)
    .addFields(
      { name: '\u200b', value: 'Aperto', inline: false },
      { name: 'Richiedente', value: `<@${user.id}>`, inline: false },
      { name: 'Stato', value: 'open', inline: false },
      { name: 'Claim', value: 'Non assegnato', inline: false }
    )
    .setFooter({
      text: 'Extra: /ticket rename, /ticket add-user, /ticket remove-user, /ticket transcript, /ticket notes.\nUtente non in blacklist.'
    });

  // Aggiunge nome dell'embed "LogixCore Ticket" come author
  embed.setAuthor({ name: 'LogixCore Ticket', iconURL: icon });

  // Se sono presenti i dati del form, li aggiunge come campi extra
  if (formData) {
    for (const [key, value] of Object.entries(formData)) {
      if (value) {
        embed.addFields({ name: key, value: value.slice(0, 1024), inline: false });
      }
    }
  }

  return embed;
}

function buildTicketControlRow(claimedById = null) {
  const closeBtn = new ButtonBuilder()
    .setCustomId('ticket_close')
    .setLabel('Chiudi')
    .setEmoji('🔒')
    .setStyle(ButtonStyle.Danger);

  const claimBtn = new ButtonBuilder()
    .setCustomId('ticket_claim')
    .setLabel('Claim')
    .setEmoji('🎫')
    .setStyle(ButtonStyle.Primary)
    .setDisabled(!!claimedById);

  const unclaimBtn = new ButtonBuilder()
    .setCustomId('ticket_unclaim')
    .setLabel('Unclaim')
    .setEmoji('🪐')
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(!claimedById);

  return new ActionRowBuilder().addComponents(closeBtn, claimBtn, unclaimBtn);
}

// ---------- Modal per ogni categoria (immagini 5-10) ----------
function buildCategoryModal(category) {
  const modal = new ModalBuilder()
    .setCustomId(`ticket_modal_${category.id}`)
    .setTitle(category.modal.title);

  const rows = category.modal.fields.map(field => {
    const input = new TextInputBuilder()
      .setCustomId(field.id)
      .setLabel(field.label)
      .setStyle(field.style === 'PARAGRAPH' ? TextInputStyle.Paragraph : TextInputStyle.Short)
      .setPlaceholder(field.placeholder || '')
      .setRequired(!!field.required);

    return new ActionRowBuilder().addComponents(input);
  });

  modal.addComponents(...rows);
  return modal;
}

// ---------- Embed transcript per DM player e canale log (immagine 1) ----------
function buildTranscriptEmbed({ category, motivo, staffTag, guildName, settings = {} }) {
  const icon = resolveIcon(settings);

  const embed = new EmbedBuilder()
    .setColor(0x2f3136)
    .setTitle('Ticket chiuso')
    .setDescription(`Server: **${guildName}**`)
    .setThumbnail(icon)
    .addFields(
      { name: 'Categoria', value: `${category.emoji} ${category.label}`, inline: false },
      { name: 'Motivo', value: motivo || 'Nessun motivo specificato', inline: false },
      { name: 'Staff', value: staffTag ? `<@${staffTag}>` : 'N/A', inline: false }
    )
    .setAuthor({ name: 'LogixCore Transcript', iconURL: icon });

  return embed;
}

module.exports = {
  buildPanelEmbed,
  buildTicketCreatedEmbed,
  buildTicketChannelEmbed,
  buildTicketControlRow,
  buildCategoryModal,
  buildTranscriptEmbed
};
