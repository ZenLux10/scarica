# LogixCore Ticket Bot

Bot Discord.js v14 multi-server per la gestione completa dei ticket, con configurazione
indipendente per ogni server tramite comando slash `/configura`.

## Funzionalità

- `/panel` — invia il pannello "Apri un ticket" con menu a tendina per le 6 categorie
  (Supporto, Acquisti, Partnership, Segnalazioni, Candidature, Altro)
- Ogni categoria apre un modal dedicato con i campi specifici
- Creazione automatica del canale ticket privato, visibile solo all'utente + ruoli staff
- Sistema di **Claim / Unclaim** per assegnare il ticket a un membro dello staff
- `/ticket` con sottocomandi:
  - `rename` — rinomina il canale ticket
  - `add-user` — aggiunge un utente al ticket
  - `remove-user` — rimuove un utente dal ticket
  - `transcript` — genera la transcript senza chiudere il ticket
  - `notes` — aggiunge una nota interna visibile nel canale
  - `close` — chiude il ticket, genera la transcript e elimina il canale
- **Transcript automatica** (HTML) inviata in DM all'utente che ha aperto il ticket e nel
  canale log configurato
- `/configura` — configurazione completa **per ogni server**, senza toccare file o riavviare il bot
- Limite di 1 ticket aperto per utente + cooldown di 120 secondi tra le aperture
- Comandi **globali** (Global commands), disponibili in tutti i server in cui è presente il bot

## Installazione

1. Estrai lo zip e installa le dipendenze:
   ```
   npm install
   ```

2. Rinomina `.env.example` in `.env` e compila SOLO le credenziali del bot:
   ```
   DISCORD_TOKEN=...
   CLIENT_ID=...
   ```
   Non serve altro nel `.env`: tutto il resto si configura da Discord con `/configura`.

3. Registra i comandi slash globali (da eseguire una sola volta o dopo ogni modifica ai comandi):
   ```
   node deploy-commands.js
   ```
   ⚠️ I comandi globali possono richiedere fino a 1 ora per propagarsi su Discord.

4. Avvia il bot:
   ```
   node index.js
   ```

## Configurazione per server: comando `/configura`

Tutte le impostazioni sono salvate **per singolo server** in `data/guilds/<guildId>.json`,
create automaticamente al primo utilizzo del comando. Richiede permesso "Gestisci server".

| Sottocomando | Descrizione |
|---|---|
| `/configura log-channel canale:#log-ticket` | Imposta il canale dove arrivano log e transcript |
| `/configura ticket-category categoria:Ticket` | Imposta la categoria Discord dove vengono creati i canali ticket |
| `/configura staff-role azione:Aggiungi ruolo:@Staff` | Aggiunge/rimuove un ruolo staff generale (gestisce tutte le categorie) |
| `/configura category-role categoria:Supporto azione:Aggiungi ruolo:@SupportTeam` | Aggiunge/rimuove un ruolo specifico per una categoria (se non impostato, usa i ruoli staff generali) |
| `/configura branding nome:"Nome Server" icona:<url>` | Personalizza nome e icona mostrati negli embed |
| `/configura view` | Mostra la configurazione attuale del server |

### Esempio di setup minimo per un nuovo server

```
/configura log-channel canale:#ticket-log
/configura staff-role azione:Aggiungi ruolo:@Staff
/panel
```

A questo punto il pannello è funzionante: i ticket aperti finiranno nella root del server
(nessuna categoria) e saranno visibili a chi ha il ruolo @Staff, con log e transcript inviati
in #ticket-log.

Per assegnare categorie specifiche a team diversi:
```
/configura category-role categoria:Acquisti azione:Aggiungi ruolo:@SalesTeam
/configura category-role categoria:Segnalazioni azione:Aggiungi ruolo:@ModTeam
```

## Whitelist server (anti-cani e porci 🐕)

Il bot funziona **solo** nei server presenti nella whitelist. Se viene aggiunto a un server
non autorizzato, lo lascia automaticamente (in DM all'owner del server gli viene inviato l'ID
da comunicarti).

Gestione tramite `/whitelist`, riservato a `BOT_OWNER_ID` (impostato nel `.env`):

| Sottocomando | Descrizione |
|---|---|
| `/whitelist add guild_id:<id>` | Autorizza un server |
| `/whitelist remove guild_id:<id>` | Rimuove un server (il bot lo lascia subito se è ancora presente) |
| `/whitelist list` | Mostra tutti i server autorizzati |
| `/whitelist check guild_id:<id>` | Controlla se un server è autorizzato |

La whitelist è salvata in `data/whitelist.json`. Per autorizzare il **tuo primo server**
(dove userai `/whitelist` la prima volta), recupera l'ID del server (tasto destro sul nome
server → Copia ID, con la modalità sviluppatore attiva) ed esegui:

```
/whitelist add guild_id:<id_del_tuo_server>
```

> Nota: la prima volta puoi anche aggiungere manualmente l'ID nel file
> `data/whitelist.json` (es. `["123456789012345678"]`) prima di invitare il bot,
> così da evitare che venga subito kickato.

## Permessi del bot richiesti

Quando inviti il bot, assicurati che abbia questi permessi:
- Manage Channels
- Manage Roles
- Send Messages
- Embed Links
- Attach Files
- Read Message History
- Use Application Commands

Scope da usare nel link OAuth2: `bot applications.commands`

## Note

- I canali ticket usano il `topic` del canale per memorizzare `TICKET|<userId>|<categoryId>`:
  non modificare manualmente il topic.
- Lo stato "Claim" è mantenuto in memoria: se il bot viene riavviato, i ticket già aperti
  torneranno a mostrare "Non assegnato" finché non viene rifatto il claim.
- La cartella `data/guilds/` contiene un file JSON per ogni server con la sua configurazione:
  fai backup di questa cartella se sposti il bot su un altro host.
- Per personalizzare le icone delle categorie ticket (icona nell'embed dentro il canale),
  modifica il campo `icon` in `config/ticketConfig.js`.
